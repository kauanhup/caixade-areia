#!/bin/bash
export LD_LIBRARY_PATH="$HOME/Caixade-Areia/lib:$LD_LIBRARY_PATH"
export QT_PLUGIN_PATH="$HOME/Caixade-Areia/plugins"
export QML2_IMPORT_PATH="$HOME/Caixade-Areia/qml"
export QML_IMPORT_PATH="$HOME/Caixade-Areia/qml"

cd "$HOME/Caixade-Areia/bin"
./caixa-de-areia
