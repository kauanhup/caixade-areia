#!/bin/bash

echo "============================================="
echo "  INSTALADOR COMPLETO - CAIXA DE AREIA"
echo "============================================="
echo ""

# ------------------------------
# Função para rodar scripts
# ------------------------------
run_script() {
    local script="$1"

    if [ -f "$script" ]; then
        echo "▶ Executando: $script"
        chmod +x "$script"
        ./"$script"
        echo "✔ Concluído: $script"
        echo ""
    else
        echo "❌ ERRO: Arquivo não encontrado: $script"
    fi
}

# ------------------------------
# Executar scripts principais
# ------------------------------
run_script "Instalar-Vrui.sh"
run_script "Instalar-Kinect.sh"
run_script "Instalar-SARndbox.sh"
run_script "adicionais.sh"

echo "============================================="
echo "  Instalação principal concluída!"
echo "============================================="
echo ""

# ------------------------------
# Mover AppImage para a pasta correta
# ------------------------------
echo "📦 Movendo AppImage para /home/…/Caixade-Areia"

mkdir -p "$HOME/Caixade-Areia"

if [ -f "Caixade-Areia.AppImage" ]; then
    mv "Caixade-Areia.AppImage" "$HOME/Caixade-Areia/"
    chmod +x "$HOME/Caixade-Areia/Caixade-Areia.AppImage"
    echo "✔ AppImage movida para: $HOME/Caixade-Areia/"
else
    echo "❌ ERRO: Caixade-Areia.AppImage não foi encontrada no diretório atual"
fi

echo ""

# ------------------------------
# Copiar AppImage para a Área de Trabalho
# ------------------------------
echo "🖥️ Copiando AppImage para a Área de Trabalho..."

DESKTOP_PATH=$(xdg-user-dir DESKTOP 2>/dev/null)

if [ -z "$DESKTOP_PATH" ] || [ ! -d "$DESKTOP_PATH" ]; then
    DESKTOP_PATH="$HOME/Desktop"
    mkdir -p "$DESKTOP_PATH"
fi

APPIMAGE="$HOME/Caixade-Areia/Caixade-Areia.AppImage"

if [ -f "$APPIMAGE" ]; then
    cp "$APPIMAGE" "$DESKTOP_PATH/"
    chmod +x "$DESKTOP_PATH/Caixade-Areia.AppImage"
    echo "✔ AppImage copiada para a Área de Trabalho!"
else
    echo "❌ ERRO: Caixade-Areia.AppImage não existe em $APPIMAGE"
fi

echo ""

# ------------------------------
# Criar arquivo .desktop
# ------------------------------
echo "📝 Criando atalho .desktop…"

DESKTOP_FILE="$HOME/.local/share/applications/caixade-areia.desktop"

mkdir -p "$HOME/.local/share/applications"

cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Name=Caixa de Areia
Comment=Simulador de Realidade Aumentada SARndbox
Exec=$HOME/Caixade-Areia/Caixade-Areia.AppImage
Icon=utilities-terminal
Terminal=false
Type=Application
Categories=Education;Science;
EOF

chmod +x "$DESKTOP_FILE"

echo "✔ Atalho criado em: $DESKTOP_FILE"
echo "✔ Ele aparecerá no menu do sistema"
echo ""

echo "============================================="
echo "  INSTALAÇÃO FINALIZADA!"
echo "============================================="
echo "Use o atalho na Área de Trabalho ou o ícone no menu."
echo ""

